Invoke-WebRequest -Uri "https://dl.walletbuilders.com/download?customer=c4833c4e46773f424605f72bf7cb1ae368b802f2dbd157d893&filename=bluchip-qt-windows.zip" -OutFile "$HOME\Downloads\bluchip-qt-windows.zip"

Start-Sleep -s 15

Expand-Archive -LiteralPath "$HOME\Downloads\bluchip-qt-windows.zip" -DestinationPath "$HOME\Desktop\BluChip"

$ConfigFile = "rpcuser=rpc_bluchip
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=127.0.0.1
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node3.walletbuilders.com"

New-Item -Path "$env:appdata" -Name "BluChip" -ItemType "directory"
New-Item -Path "$env:appdata\BluChip" -Name "BluChip.conf" -ItemType "file" -Value $ConfigFile

$MineBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
echo Press [CTRL+C] to stop mining.
:begin
 for /f %%i in ('bluchip-cli.exe getnewaddress') do set WALLET_ADDRESS=%%i
 bluchip-cli.exe generatetoaddress 1 %WALLET_ADDRESS%
goto begin"

New-Item -Path "$HOME\Desktop\BluChip" -Name "mine.bat" -ItemType "file" -Value $MineBat

Start-Process "$HOME\Desktop\BluChip\bluchip-qt.exe"

Start-Sleep -s 15

Set-Location "$HOME\Desktop\BluChip\"
Start-Process "mine.bat"